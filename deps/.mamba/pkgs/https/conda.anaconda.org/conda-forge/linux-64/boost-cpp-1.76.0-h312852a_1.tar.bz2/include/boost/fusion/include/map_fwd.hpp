/*=============================================================================
    Copyright (c) 2001-2007 Joel de Guzman

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#if !defined(FUSION_INCLUDE_MAP_FWD)
#define FUSION_INCLUDE_MAP_FWD

#include <boost/fusion/support/config.hpp>
#include <boost/fusion/container/map/map_fwd.hpp>

#endif
